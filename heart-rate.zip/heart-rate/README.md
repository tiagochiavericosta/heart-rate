# Heart Monitor Skill
Shows heartbeat using webcam

## Description
Say the command to mycroft and place a finger on the webcam lens.

## Usage:
* `what is my heart rate`
* `what my heart rate`

## Credits
Tiago Chiaveri da Costa
